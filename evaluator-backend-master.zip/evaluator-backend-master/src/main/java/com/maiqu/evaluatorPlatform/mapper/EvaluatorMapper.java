package com.maiqu.evaluatorPlatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maiqu.evaluatorPlatform.model.User;
import com.maiqu.evaluatorPlatform.model.entity.Evaluator;

/**
 * @author ht
 */
public interface EvaluatorMapper extends BaseMapper<Evaluator> {


}

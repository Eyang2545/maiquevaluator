package com.maiqu.evaluatorPlatform.model.vo;

import lombok.Data;

/**
 * @author ht
 */
@Data
public class TeamMemberVO extends UserVO{
    private Long teamId;
}

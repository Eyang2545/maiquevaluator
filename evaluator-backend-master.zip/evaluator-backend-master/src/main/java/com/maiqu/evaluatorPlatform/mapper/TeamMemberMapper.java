package com.maiqu.evaluatorPlatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maiqu.evaluatorPlatform.model.common.User;
import com.maiqu.evaluatorPlatform.model.entity.TeamMember;

/**
 * @author ht
 */
public interface TeamMemberMapper extends BaseMapper<TeamMember> {
}

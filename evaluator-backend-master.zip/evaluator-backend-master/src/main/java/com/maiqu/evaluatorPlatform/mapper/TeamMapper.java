package com.maiqu.evaluatorPlatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maiqu.evaluatorPlatform.model.entity.Team;

/**
 * @author ht
 */
public interface TeamMapper extends BaseMapper<Team> {
}

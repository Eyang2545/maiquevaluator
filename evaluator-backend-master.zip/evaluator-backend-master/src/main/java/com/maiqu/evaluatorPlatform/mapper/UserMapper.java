package com.maiqu.evaluatorPlatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maiqu.evaluatorPlatform.model.User;

/**
 * @author ht
 */
public interface UserMapper extends BaseMapper<User> {

}

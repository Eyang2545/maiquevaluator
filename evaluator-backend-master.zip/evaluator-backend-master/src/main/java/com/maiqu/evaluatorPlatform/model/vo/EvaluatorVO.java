package com.maiqu.evaluatorPlatform.model.vo;

import lombok.Data;

/**
 * @author ht
 */
@Data
public class EvaluatorVO extends UserVO{

}

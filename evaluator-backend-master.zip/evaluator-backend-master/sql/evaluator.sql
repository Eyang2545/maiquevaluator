/*
 Navicat Premium Data Transfer

 Source Server         : 远程数据库
 Source Server Type    : MySQL
 Source Server Version : 80025
 Source Host           : rm-bp18x2ks086oj7n2xho.mysql.rds.aliyuncs.com:3306
 Source Schema         : evaluator_platform

 Target Server Type    : MySQL
 Target Server Version : 80025
 File Encoding         : 65001

 Date: 16/11/2022 11:35:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for evaluator
-- ----------------------------
DROP TABLE IF EXISTS `evaluator`;
CREATE TABLE `evaluator`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `userAccount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `gender` tinyint NULL DEFAULT NULL COMMENT '0是女人，1是男人',
  `age` int NULL DEFAULT NULL,
  `createTime` datetime default CURRENT_TIMESTAMP  NULL,
  `updateTime` datetime default CURRENT_TIMESTAMP  NULL ON UPDATE CURRENT_TIMESTAMP,
  `isDelete` tinyint(3) UNSIGNED ZEROFILL NOT NULL COMMENT '逻辑删除',
  `userPassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '12345678',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
